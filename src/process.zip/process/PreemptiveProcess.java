/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package process;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Rc Zeravla
 */
public class PreemptiveProcess extends Process {
    public ArrayList<Integer> start_times;
    public ArrayList<Integer> end_times;
    //public HashMap<Integer, Integer> burst_segment;
    
    public PreemptiveProcess(int number, int arrival_time, int burst_time)
    {
        super(number, arrival_time, burst_time);
        this.start_times = new ArrayList<Integer>();
        this.end_times = new ArrayList<Integer>();
        //this.burst_segment = new ArrayList<Integer, Integer>();
    }
    
    public int getBurstSegment(int position) //return burst time of one segment
    {
        return end_times.get(position) - start_times.get(position); 
    }
}
