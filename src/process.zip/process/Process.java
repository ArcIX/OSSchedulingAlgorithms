/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package process;

/**
 *
 * @author Rc Zeravla
 */
public class Process {
    public int number;
    public int arrival_time;
    public int burst_time;
    public int start_time;
    public int end_time;
    
    public Process(int start_time, int burst_time) //this is for idle times
    {
        this.start_time = start_time;
        this.burst_time = burst_time;
    }
    
    /*
    public Process(int start_time, int end_time) //this is for idle times
    {
        this.start_time = start_time;
        this.end_time =  end_time;
    }
    */
    
    public Process(int number, int arrival_time, int burst_time)
    {
        this.number = number;
        this.arrival_time = arrival_time;
        this.burst_time = burst_time;
    }
}
